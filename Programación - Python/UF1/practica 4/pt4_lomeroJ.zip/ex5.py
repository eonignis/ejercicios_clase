i=0
suma=0
while i<=100:
	suma=i+suma
	i+=1
print("Tots els números entre el 1 i el 100 sumats entre ells són: ",suma)
