bact=1
time=0
while bact<10000000:
	bact=bact*2
	time+=3
time=time/60
print("La bacteria trigarà ",time," hores en arrivar a la xifra mortal".)