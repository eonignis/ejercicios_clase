i=-1
num=0
while num<1000:
	num=num+7
	i+=1
print("El número de múltiples de 7 entre el 1 i el 1000 són: ",i)