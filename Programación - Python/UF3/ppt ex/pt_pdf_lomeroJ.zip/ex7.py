f=open("satanic.txt","w+")
text=input("Introduce un texto: ")
