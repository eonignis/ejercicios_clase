f=open("parells.txt","a")
i=2
while i<=100:
	f.write(str(i)+'\n')
	i+=2
f.close()
